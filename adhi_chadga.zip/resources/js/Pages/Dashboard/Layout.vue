<template>
    <div>
        <Sidebar/>
        
    </div>
</template>

<script>
import Sidebar from './Sidebar.vue';

    export default {
        components: {
            Sidebar
  },
    }
</script>

<style scoped>

</style>