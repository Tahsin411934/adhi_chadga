<template>
    <div>
        <h1>About Page</h1>
        <p class="text-danger">Welcome to the About Page!</p>
    </div>
</template>

<script>
export default {
    name: 'About',
};
</script>
